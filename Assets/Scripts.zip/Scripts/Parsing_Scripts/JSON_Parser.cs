using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Newtonsoft.Json;

public class JSON_Parser : MonoBehaviour
{
    private SolarSystem solarSytemParsed;
    private Physic_Ranges ranges; //Class used to generate every physic aspect the user doesnt specify
    // Start is called before the first frame update


    /*
     * Creo que para hacer la busqueda lo mas eficiente posible
     * lo suyo seria a�adirle al mensaje que el usuario manda al chatgpt
     * un a�adido de "Estructuramelo como este ejemplo
     */

    public void LoadJson(string file)
    {
        if (File.Exists(file))
        {
            try
            {
                StreamReader sr = new StreamReader(file);

                string json = sr.ReadToEnd();

                solarSytemParsed = JsonUtility.FromJson<SolarSystem>(json);

                SolarSystem_Physics.instance.JsonRead();
            }
            catch (System.Exception ex)
            {
                Debug.LogError("Error al deserializar el JSON: " + ex.Message);
            }
        }
        else
        {
            Debug.LogError("Path doesn�t exist");
        }


    }

    public void LoadJsonFromGpt(string json)
    {

        bool valid = false;

        do
        {
            try
            {
                solarSytemParsed = new SolarSystem();
                solarSytemParsed = JsonConvert.DeserializeObject<SolarSystem>(json);
                valid = true;
            }
            catch (JsonException ex)
            {
                Debug.Log($"Error al deserializar el JSON: {ex.Message}");
            }
        }
        while (!valid);

        SolarSystem_Physics.instance.JsonRead();
    }

    //Se give the generator the numbers we took from JSON file
    public void setGenerationData(System_Generator generator)
    {
        ranges = new Physic_Ranges();
        int n_Planets = solarSytemParsed.Number_of_Planets;
        int starSize = ranges.generate_Star_Rad(solarSytemParsed.Star_Size);
        int starMass = ranges.generate_Star_Mass(starSize);

        //Star generated
        generator.setN_Planets(n_Planets);
        generator.set_Star_Size(starSize);
        generator.set_Star_Mass(starMass);

        //Generate planets
        int totalSatellites = 0;
        List<int> satellites = new List<int>();
        Planet[] planets = solarSytemParsed.Planets;
        float[] rads = new float[n_Planets];
        float[] mass = new float[n_Planets];
        Vector3[] dist = new Vector3[n_Planets];

        for (int i = 0; i < n_Planets; i++)
        {
            Planet currentPlanet = planets[i];

            Vector3 newDist = new Vector3(0, 0, 0);
            newDist.x = ranges.generate_Planet_Distance(starSize, currentPlanet.Type);

            rads[i] = ranges.generate_Planet_Rad(currentPlanet.Giant, starSize);
            mass[i] = ranges.generate_Planet_Mass(rads[i]);
            dist[i] = newDist;

            satellites.Add(currentPlanet.Satellites);
            totalSatellites += currentPlanet.Satellites;
        }

        generator.set_Planets(rads, mass, dist, planets);
        generator.set_Satellites_Numbers(satellites);

        //Generate Satellites
        int currentSatellite = 0;   //Iterate Satellites in the general array
        float[] satellite_Rads = new float[totalSatellites];
        float[] satellite_Mass = new float[totalSatellites];
        float[] satellite_Dist = new float[totalSatellites];

        //Iterate Planets
        for (int i = 0; i < planets.Length; i++)
        {

            //Iterate satellites
            for (int j = 0; j < satellites[i]; j++)
            {
                //Arrays so we can check if the satellite is generating properly
                float[] satellites_Positions = new float[satellites[i]];
                float[] satellites_Rads = new float[satellites[i]];

                float planet_Rad = rads[i];
                float planet_Pos = dist[i].x;
                float satellite_Rad = ranges.generate_Satellites_Rads(planet_Rad);
                satellite_Rads[currentSatellite] = satellite_Rad;
                satellite_Mass[currentSatellite] = ranges.generate_Satellites_Masses(satellite_Rad);

                satellites_Rads[j] = satellite_Rad;

                #region SUPERPOSITION_DETECTITION
                //Position generated from planet_Radious and planet Position
                float distance = ranges.generate_Satellite_Distance(planet_Rad, planet_Pos);
                satellites_Positions[j] = distance;

                //Check if its between both planets and outside other satellites
                if (i < planets.Length - 1)
                {   
                        //Left extreme of the planet    Right extreme                       If the satellite wont fit, we make space for it between planets
                    if((dist[i + 1].x - rads[i+1]) - (dist[i].x + rads[i]) < satellite_Rad) 
                        dist[i].x -= satellite_Rad;

                    while (!inRange(satellites_Positions, satellites_Rads, j, dist[i + 1].x, rads[i + 1]))
                    {
                        distance = ranges.generate_Satellite_Distance(planet_Rad, planet_Pos, dist[i+1].x, rads[i+1]);
                        satellites_Positions[j] = distance;
                        planet_Pos = distance;
                    }
                }
                else //Especial case for the last planet
                {
                    while (!inRange(satellites_Positions, satellites_Rads, j))
                    {
                        distance = ranges.generate_Satellite_Distance(planet_Rad, planet_Pos);
                        satellites_Positions[j] = distance;
                    }
                }

                #endregion

                satellite_Dist[currentSatellite] = distance;

                currentSatellite++;
            }

        }

        generator.set_Satellites(satellite_Rads, satellite_Mass, satellite_Dist);

    }

    /// <summary>
    /// this function determines if a determined satellite is in its logical range. 
    /// Logical beeing between its own planet and the next. And not inside other satellite of said planet
    /// </summary>
    /// <param name="nextPlanetPos"> Position of next planet. Default value for last planet </param>
    /// <param name="nextPlanetRad"> Radious of next planet. Default value for last planet </param>
    /// <param name="satellites">position of same planet satellites</param>
    /// <param name="satellitesRads">Rads of same planet satellites</param>
    /// <param name="s">Index of the current satellite</param>
    /// <returns></returns>
    private bool inRange(float[] satellites, float[] satellitesRads, int s,
        float nextPlanetPos = float.MaxValue, float nextPlanetRad = float.MaxValue / 2)
    {
        bool inRange = true;

        //Dimensions and position of current satellite
        float position = satellites[s];
        float rad = satellitesRads[s];

        //It appeared further than the next planet or inside it
        if (position > nextPlanetPos || position + rad >= nextPlanetPos - nextPlanetRad) return false;

        //We check every satellite until the one we are checking right now
        for (int i = 0; i < s; i++)
        {

            //We always check with the previous satellite
            if (position - rad <= satellites[i] + satellitesRads[i]) return false;
        }


        return inRange;
    }
}
