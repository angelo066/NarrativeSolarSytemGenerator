using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * This script defines Clases so we can parse Json with the JsonUtility
 * function "FromJson"
 */

/*
 * The following clases are used to store
 * the information directly from the Json
 */
//[System.Serializable]
//public class SolarSystem
//{
//    public int Number_of_Planets;

//    public int Star_Size;   //Dawrf Normal or Giant

//    public Planet[] Planets;

//    public string History;  //General History of the solar system
//}

//[System.Serializable]
//public class Planet
//{
//    public string Name;

//    public PlanetCharacteristics Characteristics;

//    public int Satellites;

//    public int Type;    //If it is a fire Word a Water world a Gas World or a Frozen World

//    public bool Giant;  //If we want it to be giant or not
//}

//[System.Serializable]
//public class PlanetCharacteristics
//{
//    public string Surface;

//    public string Temperature;
//}

[System.Serializable]
public class SolarSystem
{
    public int Number_of_Planets { get; set; }
    public int Star_Size { get; set; }
    public Planet[] Planets { get; set; }
    public string History { get; set; }
}
[System.Serializable]
public class Planet
{
    public string Name { get; set; }
    public PlanetCharacteristics Characteristics { get; set; }
    public int Satellites { get; set; }
    public int Type { get; set; }
    public bool Giant { get; set; }
}
[System.Serializable]
public class PlanetCharacteristics
{
    public string Surface { get; set; }
    public string Temperature { get; set; }
}

